#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import argparse
from data_management import load_data
from model_management import build_network, train_network, evaluate_model, save_model

# Parse command line arguments
parser = argparse.ArgumentParser(description='Training a neural network')
parser.add_argument('data_dir', help='dataset location)
parser.add_argument('--save_dir', help='checkpoint location')
parser.add_argument('--arch', help='Network architecture')
parser.add_argument('--hidden_units', help='Hidden units')
parser.add_argument('--epochs', help='Epochs')
parser.add_argument('--learning_rate', help='Learning rate')
parser.add_argument('--gpu', help='Use GPU for training', action='store_true')
args = parser.parse_args()

# Set hyperparameters

epochs = 10 if args.epochs is None else int(args.epochs)

hidden_units = 512 if args.hidden_units is None else int(args.hidden_units)

arch = 'vgg16' if args.arch is None else args.arch

gpu = False if args.gpu is None else True

learning_rate = 0.005 if args.learning_rate is None else float(args.learning_rate)

save_dir = '' if args.save_dir is None else args.save_dir





# Load the data
train_data, train_loader, valid_loader, test_loader = load_data(args.data_dir)

# Build the model
model = build_network(arch, hidden_units)

# Train the model
model, criterion = train_network(model, epochs, learning_rate, train_loader, valid_loader, gpu)

# Evaluate the model
evaluate_model(model, test_loader, criterion, gpu)

# Save the model
save_model(model, arch, hidden_units, epochs, learning_rate, save_dir)

