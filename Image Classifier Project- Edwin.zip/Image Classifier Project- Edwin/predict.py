#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import argparse
import json
import model_management as mm
import data_management as dm

def main():

    argument_parser = argparse.ArgumentParser(description='Predicting flower name and probability.')

    argument_parser.add_argument('--top_k', help='This will return top k most likely classes for the prediction')

    argument_parser.add_argument('checkpoint', help='checkpoint of a network')

    argument_parser.add_argument('--category_names', help='to use a mapping of categories to real names')

    argument_parser.add_argument('image_path', help='Image location')

    argument_parser.add_argument('--gpu', help='Use GPU for inference', action='store_true')

    parsed_arguments = argument_parser.parse_args()


    category_names = "cat_to_name.json" if parsed_arguments.category_names is None else parsed_arguments.category_names
    top_k = 10 if parsed_arguments.top_k is None else int(parsed_arguments.top_k)
    gpu = False if parsed_arguments.gpu is None else True

    model = mm.load_model(parsed_arguments.checkpoint)
    print(model)

    with open(category_names, 'r') as file:
        cat_to_name = json.load(file)

    probs, predict_classes = mm.predict(dm.process_image(parsed_arguments.image_path), model, top_k)

    classes = []
    for predict_class in predict_classes:
        classes.append(cat_to_name[predict_class])

    print(classes)
    print(probs)


if __name__ == '__main__':
    main()

